##
Zomato Report
I used Tableau to complete my final project. I used Google Docs to create a comprehensive write up. I hand drew my dashboard mockups, and I loom to
creat a screencast walking users through my project and how to navigate it.
https://public.tableau.com/views/Zomato-FinalProject/ZomatoKPIDashboard?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link
https://www.loom.com/share/91e19bdf60bd48778ca8603baad97c5e?sid=472e183a-d168-4da9-abba-0571cb28672b
https://www.loom.com/share/5f56219eb0c74e0f9772908887100986?sid=541ad2d7-2d80-42bc-9238-3adee366047b
https://www.loom.com/share/8c94d856e2ad43e385883b737b95db16?sid=889b9213-9d0c-4425-bd08-585ba14ab879